package com.dgs.translateofdgs

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private data class Item(val rect: Rect, val text: String)
private data class OverlayLang(val name: String, val code: String)

private class ResultView(
    ctx: Context,
    private val items: List<Item>,
    private val activeRegion: Rect?
) : View(ctx) {
    private val bgPaint = Paint().apply { color = 0xF5071216.toInt(); style = Paint.Style.FILL }
    private val strokePaint = Paint().apply {
        color = 0xFF16E0D3.toInt(); style = Paint.Style.STROKE; strokeWidth = 2.5f; isAntiAlias = true
    }
    private val regionStroke = Paint().apply {
        color = 0x9916E0D3.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f
        pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f)
    }
    private val tp = TextPaint().apply { color = Color.WHITE; isAntiAlias = true }

    private fun fit(text: String, w: Int, h: Int): StaticLayout {
        var size = (h.toFloat() * 0.72f).coerceAtMost(44f).coerceAtLeast(15f)
        while (true) {
            tp.textSize = size
            val l = StaticLayout.Builder.obtain(text, 0, text.length, tp, w).build()
            if (l.height <= h + 8 || size <= 15f) return l
            size -= 2f
        }
    }

    override fun onDraw(c: Canvas) {
        if (activeRegion != null) {
            c.drawRect(RectF(activeRegion), regionStroke)
        }
        for (item in items) {
            val r = item.rect
            val rr = RectF(r.left - 6f, r.top - 4f, r.right + 6f, r.bottom + 4f)
            c.drawRoundRect(rr, 10f, 10f, bgPaint)
            c.drawRoundRect(rr, 10f, 10f, strokePaint)
            val layout = fit(item.text, r.width().coerceAtLeast(100), r.height().coerceAtLeast(30))
            c.save()
            c.translate(r.left.toFloat(), r.top.toFloat())
            layout.draw(c)
            c.restore()
        }
    }
}

private class RegionSelectView(
    ctx: Context,
    initialRect: Rect?,
    private val onConfirm: (Rect) -> Unit,
    private val onCancel: () -> Unit
) : View(ctx) {
    private val dimPaint = Paint().apply { color = 0x99030A0D.toInt(); style = Paint.Style.FILL }
    private val clearPaint = Paint().apply {
        color = 0x2216E0D3; style = Paint.Style.FILL
    }
    private val borderPaint = Paint().apply {
        color = 0xFF16E0D3.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true
    }
    private val cornerPaint = Paint().apply {
        color = 0xFF22E8E0.toInt(); style = Paint.Style.FILL; isAntiAlias = true
    }
    private val hintPaint = TextPaint().apply {
        color = Color.WHITE; textSize = 16f * resources.displayMetrics.density; isAntiAlias = true
        textAlign = Paint.Align.CENTER
    }
    private val hintBgPaint = Paint().apply { color = 0xEE071317.toInt(); style = Paint.Style.FILL }

    private var startX = initialRect?.left?.toFloat() ?: 0f
    private var startY = initialRect?.top?.toFloat() ?: 0f
    private var endX = initialRect?.right?.toFloat() ?: 0f
    private var endY = initialRect?.bottom?.toFloat() ?: 0f
    private var hasBox = initialRect != null

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
        val banner = RectF(width * 0.08f, 60f * resources.displayMetrics.density, width * 0.92f, 108f * resources.displayMetrics.density)
        c.drawRoundRect(banner, 24f, 24f, hintBgPaint)
        c.drawRoundRect(banner, 24f, 24f, borderPaint)
        c.drawText("Çevrilecek alanı parmağınla kare içine al", width / 2f, banner.centerY() + 6f * resources.displayMetrics.density, hintPaint)

        if (hasBox) {
            val l = min(startX, endX)
            val t = min(startY, endY)
            val r = max(startX, endX)
            val b = max(startY, endY)
            val rf = RectF(l, t, r, b)
            c.drawRect(rf, clearPaint)
            c.drawRect(rf, borderPaint)
            val rad = 10f * resources.displayMetrics.density
            c.drawCircle(l, t, rad, cornerPaint)
            c.drawCircle(r, t, rad, cornerPaint)
            c.drawCircle(l, b, rad, cornerPaint)
            c.drawCircle(r, b, rad, cornerPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                endX = event.x
                endY = event.y
                hasBox = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                endX = event.x
                endY = event.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                endX = event.x
                endY = event.y
                val l = min(startX, endX).toInt()
                val t = min(startY, endY).toInt()
                val r = max(startX, endX).toInt()
                val b = max(startY, endY).toInt()
                if (abs(r - l) > 50 && abs(b - t) > 50) {
                    onConfirm(Rect(l, t, r, b))
                } else {
                    onCancel()
                }
            }
        }
        return true
    }
}

class ScreenTranslateService : Service() {
    companion object {
        const val ACTION_STOP = "com.dgs.translateofdgs.STOP"
        private const val CH = "dgs_screen"
    }

    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var bg: Handler? = null
    private var wm: WindowManager? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var playPauseLabel: TextView? = null
    private var areaLabel: TextView? = null
    private var fromLangLabel: TextView? = null
    private var toLangLabel: TextView? = null
    private var resultView: ResultView? = null
    private var selectView: RegionSelectView? = null
    private var langPickerView: LinearLayout? = null
    private var recognizer: TextRecognizer? = null

    // Başlangıç her zaman İngilizce -> Türkçe
    private var fromCode = "en"
    private var toCode = "tr"
    private var fromName = "İngilizce"
    private var toName = "Türkçe"
    private var availableLangs: List<OverlayLang> = listOf(
        OverlayLang("İngilizce", "en"),
        OverlayLang("Türkçe", "tr"),
        OverlayLang("Almanca", "de"),
        OverlayLang("Fransızca", "fr"),
        OverlayLang("İspanyolca", "es"),
        OverlayLang("Rusça", "ru"),
        OverlayLang("Arapça", "ar"),
        OverlayLang("Japonca", "ja"),
        OverlayLang("Korece", "ko"),
        OverlayLang("Çince", "zh-CN")
    )

    private var selectedRegion: Rect? = null
    private var lastBitmap: Bitmap? = null
    private var lastConv = 0L
    private var quietUntil = 0L
    private var busy = false
    private var continuous = false
    private var paused = false
    private var closing = false

    @Volatile private var pending = false
    @Volatile private var overlayShown = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        if (intent.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }
        val code = intent.getIntExtra("code", 0)
        val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        // Ekran çevirisi her zaman İngilizce -> Türkçe olarak başlar
        fromCode = "en"
        toCode = "tr"
        fromName = "İngilizce"
        toName = "Türkçe"

        val langsJson = intent.getStringExtra("langsJson")
        if (!langsJson.isNullOrBlank()) {
            try {
                val arr = JSONArray(langsJson)
                val parsed = ArrayList<OverlayLang>(arr.length())
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    parsed.add(OverlayLang(obj.getString("name"), obj.getString("code")))
                }
                if (parsed.isNotEmpty()) availableLangs = parsed
            } catch (_: Exception) { }
        }

        startAsForeground()
        if (projection != null) return START_NOT_STICKY
        try {
            setupCapture(code, data)
            showPanel()
        } catch (e: Exception) {
            toast("Ekran çevirisi başlatılamadı: ${e.localizedMessage ?: "hata"}")
            shutdown()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Ekran çevirisi", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, ScreenTranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(this, CH)
            .setContentTitle("Translate of DGS")
            .setContentText("$fromName → $toName")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Kapat", stop)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    @Suppress("DEPRECATION")
    private fun metrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        (wm ?: getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return dm
    }

    private fun setupCapture(code: Int, data: Intent) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        thread = HandlerThread("dgs-capture").also { it.start() }
        bg = Handler(thread!!.looper)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { shutdown() } }
        }, main)
        val dm = metrics()
        val r = attachReader(dm.widthPixels, dm.heightPixels)
        reader = r
        vDisplay = proj.createVirtualDisplay(
            "dgs-capture", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, bg,
        )
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private fun attachReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, bg)
        return r
    }

    private fun onFrame(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            val now = SystemClock.uptimeMillis()
            val wanted = pending && now >= quietUntil
            val periodic = !pending && !overlayShown && now >= quietUntil && now - lastConv > 500
            if (wanted || periodic) {
                val bmp = toBitmap(img)
                lastBitmap = bmp
                lastConv = now
                if (wanted) {
                    pending = false
                    main.post { process(bmp) }
                }
            }
        } catch (_: Exception) {
        } finally {
            img.close()
        }
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * img.width
        val bmp = Bitmap.createBitmap(img.width + rowPadding / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(plane.buffer)
        return if (rowPadding == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
    }

    private fun requestCapture() {
        if (busy || closing || paused) return
        busy = true
        // Yeni kareyi kendi kutularımız olmadan temiz yakalamak için mevcut kutuları kısa süreliğine kaldır
        if (overlayShown) {
            removeResultImmediate()
            lastBitmap = null
            quietUntil = SystemClock.uptimeMillis() + 320
        } else {
            quietUntil = 0L
        }
        pending = true
        main.postDelayed({
            if (pending && !closing) {
                pending = false
                val b = lastBitmap
                if (b != null) process(b)
                else {
                    busy = false
                    if (!continuous) toast("Ekran görüntüsü alınamadı, tekrar dene.")
                }
            }
        }, 800)
    }

    private fun process(bmp: Bitmap) {
        if (closing || paused) { busy = false; return }
        val rec = recognizer
        if (rec == null) { busy = false; return }

        val reg = selectedRegion
        val cropBmp: Bitmap
        val offsetX: Int
        val offsetY: Int

        if (reg != null) {
            val l = reg.left.coerceIn(0, bmp.width - 1)
            val t = reg.top.coerceIn(0, bmp.height - 1)
            val r = reg.right.coerceIn(l + 1, bmp.width)
            val b = reg.bottom.coerceIn(t + 1, bmp.height)
            cropBmp = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
            offsetX = l
            offsetY = t
        } else {
            cropBmp = bmp
            offsetX = 0
            offsetY = 0
        }

        rec.process(InputImage.fromBitmap(cropBmp, 0))
            .addOnSuccessListener { res ->
                if (closing || paused) { busy = false; return@addOnSuccessListener }
                val pr = panelRect()
                val blocks = res.textBlocks.mapNotNull { b ->
                    val rawBox = b.boundingBox ?: return@mapNotNull null
                    if (b.text.isBlank()) return@mapNotNull null
                    val globalRect = Rect(
                        rawBox.left + offsetX,
                        rawBox.top + offsetY,
                        rawBox.right + offsetX,
                        rawBox.bottom + offsetY
                    )
                    if (pr != null && Rect.intersects(globalRect, pr)) return@mapNotNull null
                    Item(globalRect, b.text.replace("\n", " ").trim())
                }.take(30)

                if (blocks.isEmpty()) {
                    busy = false
                    if (!continuous) toast("Ekranda yazı bulunamadı.")
                } else {
                    translateBlocks(blocks)
                }
            }
            .addOnFailureListener {
                busy = false
                if (!continuous) toast("Yazı okunamadı.")
            }
    }

    private fun translateBlocks(blocks: List<Item>) {
        val out = java.util.Collections.synchronizedList(ArrayList<Item>())
        val left = java.util.concurrent.atomic.AtomicInteger(blocks.size)
        fun done() {
            if (left.decrementAndGet() == 0) {
                busy = false
                if (closing || paused) return
                if (out.isEmpty()) {
                    if (!continuous) toast("Çeviri yapılamadı. İnternet bağlantını kontrol et.")
                } else {
                    showResult(ArrayList(out))
                }
            }
        }
        if (fromCode == toCode) {
            busy = false
            showResult(blocks)
            return
        }
        for (b in blocks) {
            translateText(b.text, fromCode, toCode) { res, ok ->
                if (ok && res.isNotBlank()) out.add(Item(b.rect, res))
                done()
            }
        }
    }

    private fun showResult(items: List<Item>) {
        if (closing || paused) return
        removeResultImmediate()
        val w = wm ?: return
        val v = ResultView(this, items, selectedRegion)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            w.addView(v, lp)
            resultView = v
            overlayShown = true
            bringPanelToFront()
        } catch (_: Exception) {
            toast("Çeviri ekrana çizilemedi.")
        }
    }

    private fun bringPanelToFront() {
        val w = wm ?: return
        val pv = panel ?: return
        val pl = panelParams ?: return
        try {
            w.removeViewImmediate(pv)
            w.addView(pv, pl)
        } catch (_: Exception) { }
    }

    private fun removeResultImmediate() {
        val v = resultView
        resultView = null
        overlayShown = false
        if (v != null) {
            try {
                wm?.removeViewImmediate(v)
            } catch (_: Exception) {
                try { wm?.removeView(v) } catch (_: Exception) { }
            }
        }
    }

    private fun removeSelectViewImmediate() {
        val sv = selectView
        selectView = null
        if (sv != null) {
            try {
                wm?.removeViewImmediate(sv)
            } catch (_: Exception) {
                try { wm?.removeView(sv) } catch (_: Exception) { }
            }
        }
    }

    private fun removeLangPickerImmediate() {
        val lpv = langPickerView
        langPickerView = null
        if (lpv != null) {
            try {
                wm?.removeViewImmediate(lpv)
            } catch (_: Exception) {
                try { wm?.removeView(lpv) } catch (_: Exception) { }
            }
        }
    }

    private fun openOverlayLangPicker(isSource: Boolean) {
        if (closing) return
        removeLangPickerImmediate()
        val w = wm ?: return
        val d = resources.displayMetrics.density
        fun pad(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xBB03090C.toInt())
            gravity = Gravity.CENTER
            setPadding(pad(24), pad(40), pad(24), pad(40))
            setOnClickListener { removeLangPickerImmediate() }
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(0xFA0B171C.toInt())
                cornerRadius = 18 * d
                setStroke(pad(1), 0xFF16E0D3.toInt())
            }
            setPadding(pad(14), pad(14), pad(14), pad(14))
            isClickable = true
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleTv = TextView(this).apply {
            text = if (isSource) "Kaynak Dil Seçin (133 Dil)" else "Hedef Dil Seçin (133 Dil)"
            setTextColor(0xFF16E0D3.toInt())
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val closePickerTv = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(pad(10), pad(4), pad(10), pad(4))
            setOnClickListener { removeLangPickerImmediate() }
        }
        headerRow.addView(titleTv)
        headerRow.addView(closePickerTv)
        card.addView(headerRow)

        val searchBox = EditText(this).apply {
            hint = "Dil ara… (Örn: İngilizce, Rusça)"
            setHintTextColor(0xFF8AA3A8.toInt())
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
            background = GradientDrawable().apply {
                setColor(0xFF060E12.toInt())
                cornerRadius = 10 * d
                setStroke(pad(1), 0xFF1F3A40.toInt())
            }
            setPadding(pad(10), pad(8), pad(10), pad(8))
            val lpEdit = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lpEdit.topMargin = pad(8)
            lpEdit.bottomMargin = pad(8)
            layoutParams = lpEdit
        }
        card.addView(searchBox)

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (260 * d).toInt())
        }
        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(listContainer)
        card.addView(scroll)

        fun renderList(filter: String) {
            listContainer.removeAllViews()
            val q = filter.trim().lowercase()
            val matches = if (q.isEmpty()) availableLangs else availableLangs.filter {
                it.name.lowercase().contains(q) || it.code.lowercase().contains(q)
            }
            for (lang in matches) {
                val active = (isSource && lang.code == fromCode) || (!isSource && lang.code == toCode)
                val rowTv = TextView(this).apply {
                    text = if (active) "${lang.name}  ✓" else lang.name
                    setTextColor(if (active) 0xFF16E0D3.toInt() else Color.WHITE)
                    textSize = 14f
                    setPadding(pad(10), pad(9), pad(10), pad(9))
                    if (active) {
                        setBackgroundColor(0x2616E0D3)
                    }
                    setOnClickListener {
                        if (isSource) {
                            fromCode = lang.code
                            fromName = lang.name
                            fromLangLabel?.text = fromName
                        } else {
                            toCode = lang.code
                            toName = lang.name
                            toLangLabel?.text = toName
                        }
                        removeLangPickerImmediate()
                        // Dil değiştiğinde eğer sürekli çeviri açıksa veya ekranda çeviri varsa hemen yeni dille çevir
                        if (continuous && !paused) {
                            requestCapture()
                        }
                    }
                }
                listContainer.addView(rowTv)
            }
        }

        renderList("")
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderList(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        val cardLp = LinearLayout.LayoutParams((300 * d).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT)
        root.addView(card, cardLp)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        try {
            w.addView(root, lp)
            langPickerView = root
        } catch (_: Exception) {
            toast("Dil seçici açılamadı.")
        }
    }

    private fun openRegionSelector() {
        if (closing) return
        removeResultImmediate()
        removeSelectViewImmediate()
        val w = wm ?: return
        val sv = RegionSelectView(
            ctx = this,
            initialRect = selectedRegion,
            onConfirm = { rect ->
                selectedRegion = rect
                areaLabel?.text = "Alan ✓"
                areaLabel?.setTextColor(0xFF16E0D3.toInt())
                removeSelectViewImmediate()
                bringPanelToFront()
                if (continuous && !paused) {
                    requestCapture()
                }
            },
            onCancel = {
                selectedRegion = null
                areaLabel?.text = "Alan"
                areaLabel?.setTextColor(Color.WHITE)
                removeSelectViewImmediate()
                bringPanelToFront()
                toast("Tam ekran moduna dönüldü.")
            }
        )
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            w.addView(sv, lp)
            selectView = sv
            bringPanelToFront()
        } catch (_: Exception) {
            toast("Alan seçici açılamadı.")
        }
    }

    private fun updatePlayPauseLabel() {
        val lbl = playPauseLabel ?: return
        if (paused) {
            lbl.text = "⏸ Duraklatıldı"
            lbl.setTextColor(0xFFFFD54F.toInt())
        } else if (continuous) {
            lbl.text = "⏸ Duraklat"
            lbl.setTextColor(0xFFFF8A80.toInt())
        } else {
            lbl.text = "⏸ Duraklat"
            lbl.setTextColor(Color.WHITE)
        }
    }

    private fun panelRect(): Rect? {
        val v = panel
        val lp = panelParams
        if (v == null || lp == null) return null
        return Rect(lp.x - 16, lp.y - 16, lp.x + v.width + 16, lp.y + v.height + 16)
    }

    private fun showPanel() {
        val w = wm ?: return
        val d = resources.displayMetrics.density
        fun pad(v: Int) = (v * d).toInt()
        fun label(t: String, textSizeSp: Float = 12.5f, click: (() -> Unit)?): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.setTextColor(Color.WHITE)
            tv.textSize = textSizeSp
            tv.setPadding(pad(7), pad(6), pad(7), pad(6))
            if (click != null) tv.setOnClickListener { click() }
            return tv
        }

        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.background = GradientDrawable().apply {
            setColor(0xF5071317.toInt()); cornerRadius = 20 * d; setStroke(pad(1), 0xFF16E0D3.toInt())
        }
        container.setPadding(pad(6), pad(4), pad(6), pad(4))

        // Üst Satır: Sürükleme tutamacı + Tıklanabilir Kaynak Dil ⇄ Hedef Dil seçimi
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val handle = label("⠿", 14f, null)

        val srcTv = TextView(this).apply {
            text = fromName
            setTextColor(0xFF16E0D3.toInt())
            textSize = 12f
            setPadding(pad(6), pad(4), pad(6), pad(4))
            background = GradientDrawable().apply {
                setColor(0x1F16E0D3)
                cornerRadius = 8 * d
            }
            setOnClickListener { openOverlayLangPicker(true) }
        }
        fromLangLabel = srcTv

        val swapTv = TextView(this).apply {
            text = " ⇄ "
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(pad(4), pad(4), pad(4), pad(4))
            setOnClickListener {
                val tc = fromCode; fromCode = toCode; toCode = tc
                val tn = fromName; fromName = toName; toName = tn
                fromLangLabel?.text = fromName
                toLangLabel?.text = toName
                if (continuous && !paused) requestCapture()
            }
        }

        val dstTv = TextView(this).apply {
            text = toName
            setTextColor(0xFF16E0D3.toInt())
            textSize = 12f
            setPadding(pad(6), pad(4), pad(6), pad(4))
            background = GradientDrawable().apply {
                setColor(0x1F16E0D3)
                cornerRadius = 8 * d
            }
            setOnClickListener { openOverlayLangPicker(false) }
        }
        toLangLabel = dstTv

        topRow.addView(handle)
        topRow.addView(srcTv)
        topRow.addView(swapTv)
        topRow.addView(dstTv)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = pad(12); y = pad(130) }
        panelParams = lp

        val dragListener = object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                        panel?.let { try { w.updateViewLayout(it, lp) } catch (_: Exception) { } }
                    }
                }
                return true
            }
        }
        handle.setOnTouchListener(dragListener)

        // Alt Satır: Çevir (Sürekli çeviri başlatır) | Duraklat (Metni ekranda sabit tutar) | Alan | Temizle | Kapat
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val translateBtn = label("▶ Çevir") {
            paused = false
            continuous = true
            updatePlayPauseLabel()
            main.removeCallbacks(autoRun)
            main.post(autoRun)
        }.apply { setTextColor(0xFF16E0D3.toInt()) }

        val pauseBtn = label("⏸ Duraklat") {
            // Duraklat'a basıldığında sürekli taramayı durdurur, çevrilmiş metni ekranda sabit bırakır!
            continuous = false
            paused = true
            main.removeCallbacks(autoRun)
            updatePlayPauseLabel()
            toast("Duraklatıldı — çevrilen metin ekranda sabit tutuldu.")
        }
        playPauseLabel = pauseBtn

        val areaBtn = label(if (selectedRegion != null) "Alan ✓" else "Alan") {
            if (selectView != null) {
                removeSelectViewImmediate()
            } else {
                openRegionSelector()
            }
        }
        areaLabel = areaBtn

        val clearBtn = label("Temizle") {
            continuous = false
            paused = false
            updatePlayPauseLabel()
            main.removeCallbacks(autoRun)
            removeSelectViewImmediate()
            removeResultImmediate()
        }

        val closeBtn = label("✕") { shutdown() }

        btnRow.addView(translateBtn)
        btnRow.addView(pauseBtn)
        btnRow.addView(areaBtn)
        btnRow.addView(clearBtn)
        btnRow.addView(closeBtn)

        container.addView(topRow)
        container.addView(btnRow)
        panel = container
        w.addView(container, lp)
    }

    private val autoRun = object : Runnable {
        override fun run() {
            if (continuous && !paused && !closing) {
                requestCapture()
                main.postDelayed(this, 3500)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection == null) return
        try {
            val dm = metrics()
            removeResultImmediate()
            removeSelectViewImmediate()
            removeLangPickerImmediate()
            selectedRegion = null
            areaLabel?.text = "Alan"
            areaLabel?.setTextColor(Color.WHITE)
            lastBitmap = null
            val old = reader
            val r = attachReader(dm.widthPixels, dm.heightPixels)
            reader = r
            vDisplay?.resize(dm.widthPixels, dm.heightPixels, dm.densityDpi)
            vDisplay?.surface = r.surface
            old?.close()
        } catch (_: Exception) {
            toast("Ekran döndürüldü, çeviriyi yeniden başlat.")
        }
    }

    private fun toast(t: String) {
        main.post { Toast.makeText(applicationContext, t, Toast.LENGTH_SHORT).show() }
    }

    private fun cleanup() {
        continuous = false
        paused = false
        pending = false
        busy = false
        main.removeCallbacksAndMessages(null)
        removeResultImmediate()
        removeSelectViewImmediate()
        removeLangPickerImmediate()
        val pv = panel
        panel = null
        if (pv != null) {
            try {
                wm?.removeViewImmediate(pv)
            } catch (_: Exception) {
                try { wm?.removeView(pv) } catch (_: Exception) { }
            }
        }
        try { vDisplay?.release() } catch (_: Exception) { }
        vDisplay = null
        try { reader?.close() } catch (_: Exception) { }
        reader = null
        val p = projection
        projection = null
        try { p?.stop() } catch (_: Exception) { }
        try { recognizer?.close() } catch (_: Exception) { }
        recognizer = null
        try { thread?.quitSafely() } catch (_: Exception) { }
        thread = null
    }

    private fun shutdown() {
        if (closing) return
        closing = true
        if (Looper.myLooper() == Looper.getMainLooper()) {
            cleanup()
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
            stopSelf()
        } else {
            main.post {
                cleanup()
                stopForeground(Service.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        closing = true
        cleanup()
        super.onDestroy()
    }
}
